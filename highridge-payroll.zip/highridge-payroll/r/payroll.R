# =============================================================================
# Highridge Construction Company
# Weekly Payroll & Payment Slip Generator (R)
#
# R conversion of python/payroll.py. Same structure, same rules, same output.
#
# Employee level rules (from the project brief):
#   * Salary > $7,500 and < $30,000 and gender is female  -> "A5-F"
#   * Salary > $10,000 and < $20,000                       -> "A1"
#   * Any other worker                                     -> "Standard"
#
# Run:
#   Rscript payroll.R                     # 400 workers, all slips printed
#   Rscript payroll.R --workers 650       # larger workforce
#   Rscript payroll.R --quiet             # summary only, files still saved
#   RStudio: open this file and click "Source"
# =============================================================================

# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------
COMPANY_NAME <- "HIGHRIDGE CONSTRUCTION COMPANY"
MIN_WORKERS  <- 400     # brief requires at least 400 workers
DEFAULT_SEED <- 2026    # fixed seed so results can be reproduced
TAX_RATE     <- 0.12    # flat withholding rate shown on each slip

# Weekly salary band (USD) for each construction role.
ROLE_SALARY_BANDS <- list(
  "General Laborer"    = c(5000, 11000),
  "Carpenter"          = c(8000, 16000),
  "Mason"              = c(8500, 17000),
  "Electrician"        = c(11000, 22000),
  "Plumber"            = c(10500, 21000),
  "Heavy Equipment Op" = c(12000, 24000),
  "Site Supervisor"    = c(18000, 29000),
  "Project Manager"    = c(24000, 35000)
)

SITES <- c("Riverside Tower", "Northgate Bridge", "Eastview Mall",
           "Harbor Logistics Hub", "Summit Residences")

FIRST_NAMES_F <- c("Amara", "Grace", "Sofia", "Naomi", "Leah", "Imani",
                   "Chloe", "Esther", "Priya", "Yuna", "Camila", "Hannah")
FIRST_NAMES_M <- c("Marcus", "Daniel", "Elijah", "Mateo", "Samuel", "Kwame",
                   "Ethan", "Jae-won", "Isaac", "Andre", "Lucas", "Caleb")
LAST_NAMES <- c("Okafor", "Bennett", "Reyes", "Kim", "Mensah", "Carter",
                "Alvarez", "Park", "Thompson", "Osei", "Brooks", "Nguyen",
                "Hughes", "Delgado", "Coleman", "Asante")

LEVEL_A5F      <- "A5-F"
LEVEL_A1       <- "A1"
LEVEL_STANDARD <- "Standard"

# -----------------------------------------------------------------------------
# Custom error conditions (R equivalent of Python exception classes)
# -----------------------------------------------------------------------------
payroll_error <- function(message, subclass = character()) {
  structure(
    class = c(subclass, "payroll_error", "error", "condition"),
    list(message = message, call = NULL)
  )
}

invalid_worker_error <- function(message) {
  payroll_error(message, subclass = "invalid_worker_error")
}

# -----------------------------------------------------------------------------
# Data model: validated worker record
# -----------------------------------------------------------------------------
new_worker <- function(employee_id, first_name, last_name, gender,
                       role, site, weekly_salary) {
  if (is.null(employee_id) || !nzchar(employee_id)) {
    stop(invalid_worker_error("Employee ID is missing."))
  }
  if (!(gender %in% c("Female", "Male"))) {
    stop(invalid_worker_error(sprintf(
      "%s: gender must be 'Female' or 'Male', got '%s'.", employee_id, gender)))
  }
  if (!is.numeric(weekly_salary) || length(weekly_salary) != 1) {
    stop(invalid_worker_error(sprintf(
      "%s: salary must be numeric, got %s.", employee_id, class(weekly_salary)[1])))
  }
  if (weekly_salary <= 0) {
    stop(invalid_worker_error(sprintf(
      "%s: salary must be greater than zero.", employee_id)))
  }

  structure(
    list(employee_id = employee_id, first_name = first_name,
         last_name = last_name, gender = gender, role = role,
         site = site, weekly_salary = weekly_salary),
    class = "worker"
  )
}

# -----------------------------------------------------------------------------
# Workforce generation (dynamic list of workers)
# -----------------------------------------------------------------------------
generate_workforce <- function(count = MIN_WORKERS, seed = DEFAULT_SEED) {
  if (!is.numeric(count) || length(count) != 1 ||
      count %% 1 != 0 || count < MIN_WORKERS) {
    stop(sprintf("Workforce size must be a whole number of at least %d; got %s.",
                 MIN_WORKERS, deparse(count)))
  }

  set.seed(seed)
  roles <- names(ROLE_SALARY_BANDS)
  workforce <- vector("list", count)

  for (number in seq_len(count)) {
    gender     <- sample(c("Female", "Male"), 1)
    first_pool <- if (gender == "Female") FIRST_NAMES_F else FIRST_NAMES_M
    role       <- sample(roles, 1)
    band       <- ROLE_SALARY_BANDS[[role]]

    workforce[[number]] <- new_worker(
      employee_id   = sprintf("HRC-%04d", number),
      first_name    = sample(first_pool, 1),
      last_name     = sample(LAST_NAMES, 1),
      gender        = gender,
      role          = role,
      site          = sample(SITES, 1),
      weekly_salary = round(runif(1, band[1], band[2]), 2)
    )
  }

  workforce
}

# -----------------------------------------------------------------------------
# Business rules
# -----------------------------------------------------------------------------
# The two rules in the brief overlap: a female worker earning between
# $10,000 and $20,000 satisfies both. The more specific rule (A5-F, which adds
# a gender condition) is evaluated first, so it takes precedence.
classify_employee_level <- function(salary, gender) {
  if (salary > 7500 && salary < 30000 && gender == "Female") {
    LEVEL_A5F
  } else if (salary > 10000 && salary < 20000) {
    LEVEL_A1
  } else {
    LEVEL_STANDARD
  }
}

# Friday that closes the current pay week
week_ending <- function(today = Sys.Date()) {
  weekday <- as.POSIXlt(today)$wday          # 0 = Sunday ... 5 = Friday
  today + ((5 - weekday) %% 7)
}

build_payslip <- function(worker, period_end) {
  gross <- worker$weekly_salary
  tax   <- round(gross * TAX_RATE, 2)
  c(unclass(worker), list(
    employee_level = classify_employee_level(gross, worker$gender),
    period_end     = format(period_end, "%Y-%m-%d"),
    gross_pay      = gross,
    tax_withheld   = tax,
    net_pay        = round(gross - tax, 2)
  ))
}

center_text <- function(text, width = 50) {
  pad <- max(width - nchar(text), 0)
  paste0(strrep(" ", pad %/% 2), text, strrep(" ", pad - pad %/% 2))
}

money <- function(x) {
  paste0("$", formatC(x, format = "f", digits = 2, big.mark = ",", width = 12))
}

format_payslip <- function(slip) {
  line <- strrep("=", 50)
  thin <- strrep("-", 50)
  paste(c(
    line,
    center_text(COMPANY_NAME),
    center_text("WEEKLY PAYMENT SLIP"),
    line,
    paste0("Pay Period Ending : ", slip$period_end),
    paste0("Employee ID       : ", slip$employee_id),
    paste0("Name              : ", slip$first_name, " ", slip$last_name),
    paste0("Gender            : ", slip$gender),
    paste0("Role              : ", slip$role),
    paste0("Site              : ", slip$site),
    paste0("Employee Level    : ", slip$employee_level),
    thin,
    paste0("Gross Pay         : ", money(slip$gross_pay)),
    paste0(formatC(sprintf("Tax (%d%%)", round(TAX_RATE * 100)), width = -18),
           ": ", money(slip$tax_withheld)),
    paste0("Net Pay           : ", money(slip$net_pay)),
    line
  ), collapse = "\n")
}

# -----------------------------------------------------------------------------
# Payroll run
# -----------------------------------------------------------------------------
run_payroll <- function(workforce, period_end, show_slips = TRUE) {
  slips    <- list()
  failures <- character()

  for (worker in workforce) {
    result <- tryCatch({
      if (!inherits(worker, "worker")) {
        stop(invalid_worker_error(sprintf(
          "Expected a worker record, got %s.", class(worker)[1])))
      }
      slip <- build_payslip(worker, period_end)
      if (show_slips) cat(format_payslip(slip), "\n\n", sep = "")
      list(ok = TRUE, value = slip)
    },
    payroll_error = function(e) {
      message("WARNING: Skipped record: ", conditionMessage(e))
      list(ok = FALSE, value = conditionMessage(e))
    },
    error = function(e) {                     # last-resort guard
      message("WARNING: Unexpected error: ", conditionMessage(e))
      list(ok = FALSE, value = paste("Unexpected error:", conditionMessage(e)))
    })

    if (result$ok) {
      slips[[length(slips) + 1]] <- result$value
    } else {
      failures <- c(failures, result$value)
    }
  }

  list(slips = slips, failures = failures)
}

export_slips <- function(slips, output_dir) {
  if (length(slips) == 0) {
    stop(payroll_error("No payment slips to export."))
  }

  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  csv_path <- file.path(output_dir, "payment_slips.csv")
  txt_path <- file.path(output_dir, "payment_slips.txt")

  slip_table <- do.call(rbind, lapply(slips, as.data.frame,
                                      stringsAsFactors = FALSE))
  write.csv(slip_table, csv_path, row.names = FALSE)
  writeLines(paste(vapply(slips, format_payslip, character(1)),
                   collapse = "\n\n"), txt_path)

  c(csv_path, txt_path)
}

print_summary <- function(slips, failures) {
  levels_found <- vapply(slips, function(s) s$employee_level, character(1))
  total_gross  <- sum(vapply(slips, function(s) s$gross_pay, numeric(1)))
  total_net    <- sum(vapply(slips, function(s) s$net_pay, numeric(1)))
  fmt <- function(x) formatC(x, format = "f", digits = 2, big.mark = ",")

  cat("\n", strrep("#", 50), "\n", center_text("PAYROLL SUMMARY"), "\n",
      strrep("#", 50), "\n", sep = "")
  cat("Payment slips generated : ", length(slips), "\n", sep = "")
  cat("Records skipped         : ", length(failures), "\n", sep = "")
  for (level in c(LEVEL_A5F, LEVEL_A1, LEVEL_STANDARD)) {
    cat(sprintf("  Level %-10s      : %d\n", level, sum(levels_found == level)))
  }
  cat("Total gross payroll     : $", fmt(total_gross), "\n", sep = "")
  cat("Total net payroll       : $", fmt(total_net), "\n", sep = "")
}

# -----------------------------------------------------------------------------
# Entry point
# -----------------------------------------------------------------------------
parse_args <- function(args = commandArgs(trailingOnly = TRUE)) {
  opts <- list(workers = MIN_WORKERS, seed = DEFAULT_SEED,
               output_dir = "output", quiet = FALSE)
  i <- 1
  while (i <= length(args)) {
    key <- args[i]
    if (key == "--quiet") {
      opts$quiet <- TRUE
    } else if (key %in% c("--workers", "--seed", "--output-dir") &&
               i < length(args)) {
      value <- args[i + 1]
      if (key == "--output-dir") {
        opts$output_dir <- value
      } else {
        number <- suppressWarnings(as.numeric(value))
        if (is.na(number)) stop(sprintf("%s needs a number, got '%s'.", key, value))
        opts[[sub("--", "", key)]] <- number
      }
      i <- i + 1
    }
    i <- i + 1
  }
  opts
}

main <- function(args = commandArgs(trailingOnly = TRUE)) {
  setup <- tryCatch({
    opts <- parse_args(args)
    list(opts = opts, workforce = generate_workforce(opts$workers, opts$seed))
  }, error = function(e) {
    message("Configuration error: ", conditionMessage(e))
    NULL
  })
  if (is.null(setup)) return(1L)

  period_end <- week_ending()
  cat(sprintf("Processing payroll for %d workers (week ending %s)...\n\n",
              length(setup$workforce), format(period_end, "%Y-%m-%d")))

  run <- run_payroll(setup$workforce, period_end,
                     show_slips = !setup$opts$quiet)
  print_summary(run$slips, run$failures)

  tryCatch({
    for (path in export_slips(run$slips, setup$opts$output_dir)) {
      cat("Saved: ", path, "\n", sep = "")
    }
    0L
  }, payroll_error = function(e) {
    message("Export skipped: ", conditionMessage(e))
    1L
  }, error = function(e) {
    message("Could not write output files: ", conditionMessage(e))
    1L
  })
}

# Runs automatically with Rscript or RStudio "Source".
# The test file sets HRC_SKIP_MAIN so it can load the functions only.
if (!exists("HRC_SKIP_MAIN")) {
  exit_status <- main()
  if (!interactive()) quit(status = exit_status)
}
