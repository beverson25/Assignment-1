# =============================================================================
# Tests for payroll.R (base R only, no packages needed)
# Run from the r/ folder:  Rscript test_payroll.R
# =============================================================================

HRC_SKIP_MAIN <- TRUE
source("payroll.R")
rm(HRC_SKIP_MAIN)   # so a later "Source" of payroll.R runs normally

passed <- 0
failed <- 0

check <- function(description, condition) {
  ok <- tryCatch(isTRUE(condition), error = function(e) FALSE)
  if (ok) {
    passed <<- passed + 1
    cat("PASS  ", description, "\n")
  } else {
    failed <<- failed + 1
    cat("FAIL  ", description, "\n")
  }
}

raises <- function(expr, class = "error") {
  tryCatch({ force(expr); FALSE }, condition = function(e) inherits(e, class))
}

# --- Employee level rules ----------------------------------------------------
check("A1: male at 15,000",                classify_employee_level(15000, "Male") == "A1")
check("A1: 10,000 is excluded",            classify_employee_level(10000, "Male") == "Standard")
check("A1: 20,000 is excluded",            classify_employee_level(20000, "Male") == "Standard")
check("A1: 10,000.01 is included",         classify_employee_level(10000.01, "Male") == "A1")
check("A1: 19,999.99 is included",         classify_employee_level(19999.99, "Male") == "A1")
check("A5-F: female at 8,000",             classify_employee_level(8000, "Female") == "A5-F")
check("A5-F: female at 25,000",            classify_employee_level(25000, "Female") == "A5-F")
check("A5-F: 7,500 is excluded",           classify_employee_level(7500, "Female") == "Standard")
check("A5-F: 30,000 is excluded",          classify_employee_level(30000, "Female") == "Standard")
check("Overlap: female at 15,000 is A5-F", classify_employee_level(15000, "Female") == "A5-F")
check("Male at 25,000 is Standard",        classify_employee_level(25000, "Male") == "Standard")

# --- Workforce ---------------------------------------------------------------
check("Default workforce is 400",          length(generate_workforce()) == 400)
check("Workforce of 750",                  length(generate_workforce(750)) == 750)
check("Rejects 399 workers",               raises(generate_workforce(399)))
check("Rejects text input",                raises(generate_workforce("400")))
ids <- vapply(generate_workforce(), function(w) w$employee_id, character(1))
check("Employee IDs are unique",           length(unique(ids)) == length(ids))
check("Same seed gives same workforce",    identical(generate_workforce(seed = 7),
                                                     generate_workforce(seed = 7)))

# --- Validation and error handling --------------------------------------------
make_worker <- function(gender = "Female", salary = 12000) {
  new_worker("HRC-9999", "Test", "User", gender, "Carpenter",
             "Riverside Tower", salary)
}
check("Non-numeric salary rejected",       raises(make_worker(salary = "twelve"),
                                                  "invalid_worker_error"))
check("Negative salary rejected",          raises(make_worker(salary = -50),
                                                  "invalid_worker_error"))
check("Invalid gender rejected",           raises(make_worker(gender = ""),
                                                  "invalid_worker_error"))

workforce <- generate_workforce()
workforce <- append(workforce, list(list(not = "a worker")), after = 10)
run <- suppressMessages(run_payroll(workforce, as.Date("2026-10-16"), FALSE))
check("Bad record skipped, 400 slips still made",
      length(run$slips) == 400 && length(run$failures) == 1)
check("Export rejects empty payroll",      raises(export_slips(list(), tempdir()),
                                                  "payroll_error"))

# --- Payslip -----------------------------------------------------------------
slip <- build_payslip(generate_workforce()[[1]], as.Date("2026-10-16"))
check("Net pay = gross - tax",             abs(slip$net_pay - (slip$gross_pay - slip$tax_withheld)) < 0.01)
check("Week ending is a Friday",           as.POSIXlt(week_ending(as.Date("2026-10-12")))$wday == 5)
check("Friday stays the same Friday",      week_ending(as.Date("2026-10-16")) == as.Date("2026-10-16"))

cat(sprintf("\n%d passed, %d failed\n", passed, failed))
if (!interactive()) quit(status = if (failed == 0) 0 else 1)
