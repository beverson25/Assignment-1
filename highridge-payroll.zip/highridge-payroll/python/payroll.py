"""
Highridge Construction Company
Weekly Payroll & Payment Slip Generator (Python)

Generates a workforce of at least 400 construction workers, assigns each
worker an employee level, and produces a weekly payment slip for every
worker. Slips are printed to the console and exported to CSV and TXT.

Employee level rules (from the project brief):
    * Salary > $7,500 and < $30,000 and gender is female  -> "A5-F"
    * Salary > $10,000 and < $20,000                       -> "A1"
    * Any other worker                                     -> "Standard"

Run:
    python payroll.py                      # 400 workers, all slips printed
    python payroll.py --workers 650        # larger workforce
    python payroll.py --quiet              # summary only, files still saved
"""

from __future__ import annotations

import argparse
import csv
import logging
import random
import sys
from dataclasses import dataclass, asdict
from datetime import date, timedelta
from pathlib import Path

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
COMPANY_NAME = "HIGHRIDGE CONSTRUCTION COMPANY"
MIN_WORKERS = 400          # brief requires at least 400 workers
DEFAULT_SEED = 2026        # fixed seed so results can be reproduced
TAX_RATE = 0.12            # flat withholding rate shown on each slip

# Weekly salary band (USD) for each construction role.
# Bands overlap the level thresholds so every level appears in the output.
ROLE_SALARY_BANDS = {
    "General Laborer":    (5_000, 11_000),
    "Carpenter":          (8_000, 16_000),
    "Mason":              (8_500, 17_000),
    "Electrician":        (11_000, 22_000),
    "Plumber":            (10_500, 21_000),
    "Heavy Equipment Op": (12_000, 24_000),
    "Site Supervisor":    (18_000, 29_000),
    "Project Manager":    (24_000, 35_000),
}

SITES = ["Riverside Tower", "Northgate Bridge", "Eastview Mall",
         "Harbor Logistics Hub", "Summit Residences"]

FIRST_NAMES_F = ["Amara", "Grace", "Sofia", "Naomi", "Leah", "Imani",
                 "Chloe", "Esther", "Priya", "Yuna", "Camila", "Hannah"]
FIRST_NAMES_M = ["Marcus", "Daniel", "Elijah", "Mateo", "Samuel", "Kwame",
                 "Ethan", "Jae-won", "Isaac", "Andre", "Lucas", "Caleb"]
LAST_NAMES = ["Okafor", "Bennett", "Reyes", "Kim", "Mensah", "Carter",
              "Alvarez", "Park", "Thompson", "Osei", "Brooks", "Nguyen",
              "Hughes", "Delgado", "Coleman", "Asante"]

LEVEL_A5F = "A5-F"
LEVEL_A1 = "A1"
LEVEL_STANDARD = "Standard"

logger = logging.getLogger("highridge.payroll")


# ---------------------------------------------------------------------------
# Custom exceptions
# ---------------------------------------------------------------------------
class PayrollError(Exception):
    """Base class for all payroll-related errors."""


class InvalidWorkerError(PayrollError):
    """Raised when a worker record contains missing or invalid data."""


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------
@dataclass
class Worker:
    employee_id: str
    first_name: str
    last_name: str
    gender: str
    role: str
    site: str
    weekly_salary: float

    def __post_init__(self) -> None:
        """Validate the record as soon as it is created."""
        if not self.employee_id:
            raise InvalidWorkerError("Employee ID is missing.")
        if self.gender not in ("Female", "Male"):
            raise InvalidWorkerError(
                f"{self.employee_id}: gender must be 'Female' or 'Male', "
                f"got '{self.gender}'.")
        if isinstance(self.weekly_salary, bool) or not isinstance(
                self.weekly_salary, (int, float)):
            raise InvalidWorkerError(
                f"{self.employee_id}: salary must be numeric, got "
                f"{type(self.weekly_salary).__name__}.")
        if self.weekly_salary <= 0:
            raise InvalidWorkerError(
                f"{self.employee_id}: salary must be greater than zero.")

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"


# ---------------------------------------------------------------------------
# Workforce generation (dynamic list of workers)
# ---------------------------------------------------------------------------
def generate_workforce(count: int = MIN_WORKERS,
                       seed: int = DEFAULT_SEED) -> list[Worker]:
    """Dynamically build a list of `count` workers with realistic data."""
    if not isinstance(count, int) or count < MIN_WORKERS:
        raise ValueError(
            f"Workforce size must be a whole number of at least "
            f"{MIN_WORKERS}; got {count!r}.")

    rng = random.Random(seed)
    roles = list(ROLE_SALARY_BANDS)
    workforce: list[Worker] = []

    for number in range(1, count + 1):
        gender = rng.choice(["Female", "Male"])
        first_pool = FIRST_NAMES_F if gender == "Female" else FIRST_NAMES_M
        role = rng.choice(roles)
        low, high = ROLE_SALARY_BANDS[role]

        workforce.append(Worker(
            employee_id=f"HRC-{number:04d}",
            first_name=rng.choice(first_pool),
            last_name=rng.choice(LAST_NAMES),
            gender=gender,
            role=role,
            site=rng.choice(SITES),
            weekly_salary=round(rng.uniform(low, high), 2),
        ))

    return workforce


# ---------------------------------------------------------------------------
# Business rules
# ---------------------------------------------------------------------------
def classify_employee_level(salary: float, gender: str) -> str:
    """
    Return the employee level for a given salary and gender.

    The two rules in the brief overlap: a female worker earning between
    $10,000 and $20,000 satisfies both. The more specific rule (A5-F, which
    adds a gender condition) is evaluated first, so it takes precedence.
    """
    if 7_500 < salary < 30_000 and gender == "Female":
        return LEVEL_A5F
    elif 10_000 < salary < 20_000:
        return LEVEL_A1
    return LEVEL_STANDARD


def week_ending(today: date | None = None) -> date:
    """Return the Friday that closes the current pay week."""
    today = today or date.today()
    return today + timedelta(days=(4 - today.weekday()) % 7)


def build_payslip(worker: Worker, period_end: date) -> dict:
    """Combine worker data, employee level and pay figures into one slip."""
    gross = worker.weekly_salary
    tax = round(gross * TAX_RATE, 2)
    return {
        **asdict(worker),
        "employee_level": classify_employee_level(gross, worker.gender),
        "period_end": period_end.isoformat(),
        "gross_pay": gross,
        "tax_withheld": tax,
        "net_pay": round(gross - tax, 2),
    }


def format_payslip(slip: dict) -> str:
    """Render one payment slip as a readable text block."""
    line = "=" * 50
    thin = "-" * 50
    return "\n".join([
        line,
        f"{COMPANY_NAME:^50}",
        f"{'WEEKLY PAYMENT SLIP':^50}",
        line,
        f"Pay Period Ending : {slip['period_end']}",
        f"Employee ID       : {slip['employee_id']}",
        f"Name              : {slip['first_name']} {slip['last_name']}",
        f"Gender            : {slip['gender']}",
        f"Role              : {slip['role']}",
        f"Site              : {slip['site']}",
        f"Employee Level    : {slip['employee_level']}",
        thin,
        f"Gross Pay         : ${slip['gross_pay']:>12,.2f}",
        f"{f'Tax ({TAX_RATE:.0%})':<18}: ${slip['tax_withheld']:>12,.2f}",
        f"Net Pay           : ${slip['net_pay']:>12,.2f}",
        line,
    ])


# ---------------------------------------------------------------------------
# Payroll run
# ---------------------------------------------------------------------------
def run_payroll(workforce: list[Worker], period_end: date,
                show_slips: bool = True) -> tuple[list[dict], list[str]]:
    """Generate a payment slip for every worker; never stop on one bad record."""
    slips: list[dict] = []
    failures: list[str] = []

    for worker in workforce:
        try:
            if not isinstance(worker, Worker):
                raise InvalidWorkerError(
                    f"Expected a Worker record, got {type(worker).__name__}.")
            slip = build_payslip(worker, period_end)
            slips.append(slip)
            if show_slips:
                print(format_payslip(slip), end="\n\n")
        except PayrollError as err:
            failures.append(str(err))
            logger.warning("Skipped record: %s", err)
        except (TypeError, ValueError, KeyError) as err:
            failures.append(f"Data error: {err}")
            logger.warning("Data error: %s", err)
        except Exception as err:  # last-resort guard; payroll must finish
            failures.append(f"Unexpected error: {err}")
            logger.exception("Unexpected error while processing a worker")

    return slips, failures


def export_slips(slips: list[dict], output_dir: Path) -> list[Path]:
    """Save all slips to CSV (for data use) and TXT (printable)."""
    if not slips:
        raise PayrollError("No payment slips to export.")

    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / "payment_slips.csv"
    txt_path = output_dir / "payment_slips.txt"

    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(slips[0].keys()))
        writer.writeheader()
        writer.writerows(slips)

    with txt_path.open("w", encoding="utf-8") as f:
        f.write("\n\n".join(format_payslip(s) for s in slips))

    return [csv_path, txt_path]


def print_summary(slips: list[dict], failures: list[str]) -> None:
    total_gross = sum(s["gross_pay"] for s in slips)
    total_net = sum(s["net_pay"] for s in slips)
    print("\n" + "#" * 50)
    print(f"{'PAYROLL SUMMARY':^50}")
    print("#" * 50)
    print(f"Payment slips generated : {len(slips)}")
    print(f"Records skipped         : {len(failures)}")
    for level in (LEVEL_A5F, LEVEL_A1, LEVEL_STANDARD):
        count = sum(1 for s in slips if s["employee_level"] == level)
        print(f"  Level {level:<10}      : {count}")
    print(f"Total gross payroll     : ${total_gross:,.2f}")
    print(f"Total net payroll       : ${total_net:,.2f}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Highridge Construction weekly payroll generator")
    parser.add_argument("--workers", type=int, default=MIN_WORKERS,
                        help=f"number of workers (minimum {MIN_WORKERS})")
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED,
                        help="random seed for reproducible results")
    parser.add_argument("--output-dir", type=Path, default=Path("output"),
                        help="folder for CSV and TXT exports")
    parser.add_argument("--quiet", action="store_true",
                        help="print the summary only, not every slip")
    # parse_known_args lets the script also run inside notebooks (e.g. Colab)
    args, _ = parser.parse_known_args(argv)
    return args


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.WARNING,
                        format="%(levelname)s: %(message)s")
    args = parse_args(argv)

    try:
        workforce = generate_workforce(args.workers, args.seed)
    except ValueError as err:
        print(f"Configuration error: {err}", file=sys.stderr)
        return 1

    period_end = week_ending()
    print(f"Processing payroll for {len(workforce)} workers "
          f"(week ending {period_end})...\n")

    slips, failures = run_payroll(workforce, period_end,
                                  show_slips=not args.quiet)
    print_summary(slips, failures)

    try:
        for path in export_slips(slips, args.output_dir):
            print(f"Saved: {path}")
    except PayrollError as err:
        print(f"Export skipped: {err}", file=sys.stderr)
        return 1
    except OSError as err:
        print(f"Could not write output files: {err}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    try:
        status = main()
    except KeyboardInterrupt:
        print("\nPayroll run cancelled by user.", file=sys.stderr)
        status = 130
    # In a notebook (e.g. Colab) exiting would show a SystemExit warning,
    # so the exit code is only returned when run as a script.
    if "ipykernel" not in sys.modules:
        sys.exit(status)
