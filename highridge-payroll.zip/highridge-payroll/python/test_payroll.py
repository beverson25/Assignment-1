"""
Unit tests for payroll.py

Run:  python -m unittest test_payroll.py -v
"""

import tempfile
import unittest
from datetime import date
from pathlib import Path

import payroll as pr


class TestEmployeeLevel(unittest.TestCase):
    """Checks every boundary of the two level rules in the brief."""

    def test_a1_male_inside_range(self):
        self.assertEqual(pr.classify_employee_level(15_000, "Male"), "A1")

    def test_a1_lower_boundary_is_exclusive(self):
        self.assertEqual(pr.classify_employee_level(10_000, "Male"), "Standard")

    def test_a1_upper_boundary_is_exclusive(self):
        self.assertEqual(pr.classify_employee_level(20_000, "Male"), "Standard")

    def test_a1_just_inside_boundaries(self):
        self.assertEqual(pr.classify_employee_level(10_000.01, "Male"), "A1")
        self.assertEqual(pr.classify_employee_level(19_999.99, "Male"), "A1")

    def test_a5f_female_inside_range(self):
        self.assertEqual(pr.classify_employee_level(8_000, "Female"), "A5-F")
        self.assertEqual(pr.classify_employee_level(25_000, "Female"), "A5-F")

    def test_a5f_boundaries_are_exclusive(self):
        self.assertEqual(pr.classify_employee_level(7_500, "Female"), "Standard")
        self.assertEqual(pr.classify_employee_level(30_000, "Female"), "Standard")

    def test_overlap_female_in_a1_range_gets_a5f(self):
        self.assertEqual(pr.classify_employee_level(15_000, "Female"), "A5-F")

    def test_male_in_a5f_range_only_is_standard(self):
        self.assertEqual(pr.classify_employee_level(25_000, "Male"), "Standard")


class TestWorkforce(unittest.TestCase):

    def test_default_size_is_400(self):
        self.assertEqual(len(pr.generate_workforce()), 400)

    def test_larger_workforce(self):
        self.assertEqual(len(pr.generate_workforce(750)), 750)

    def test_rejects_fewer_than_400(self):
        with self.assertRaises(ValueError):
            pr.generate_workforce(399)

    def test_rejects_non_integer(self):
        with self.assertRaises(ValueError):
            pr.generate_workforce("400")

    def test_ids_are_unique(self):
        ids = [w.employee_id for w in pr.generate_workforce()]
        self.assertEqual(len(ids), len(set(ids)))

    def test_same_seed_same_workforce(self):
        self.assertEqual(pr.generate_workforce(seed=7), pr.generate_workforce(seed=7))


class TestValidationAndErrors(unittest.TestCase):

    def make(self, **overrides):
        data = dict(employee_id="HRC-9999", first_name="Test", last_name="User",
                    gender="Female", role="Carpenter", site="Riverside Tower",
                    weekly_salary=12_000.0)
        data.update(overrides)
        return pr.Worker(**data)

    def test_non_numeric_salary_rejected(self):
        with self.assertRaises(pr.InvalidWorkerError):
            self.make(weekly_salary="twelve thousand")

    def test_negative_salary_rejected(self):
        with self.assertRaises(pr.InvalidWorkerError):
            self.make(weekly_salary=-50)

    def test_invalid_gender_rejected(self):
        with self.assertRaises(pr.InvalidWorkerError):
            self.make(gender="")

    def test_bad_record_does_not_stop_payroll(self):
        workforce = pr.generate_workforce()
        workforce.insert(10, {"not": "a worker"})
        slips, failures = pr.run_payroll(workforce, date(2026, 10, 16),
                                         show_slips=False)
        self.assertEqual(len(slips), 400)
        self.assertEqual(len(failures), 1)

    def test_export_rejects_empty_payroll(self):
        with self.assertRaises(pr.PayrollError):
            pr.export_slips([], Path(tempfile.mkdtemp()))


class TestPayslip(unittest.TestCase):

    def test_net_pay_math(self):
        worker = pr.generate_workforce()[0]
        slip = pr.build_payslip(worker, date(2026, 10, 16))
        self.assertAlmostEqual(slip["net_pay"],
                               slip["gross_pay"] - slip["tax_withheld"], places=2)

    def test_week_ending_is_friday(self):
        self.assertEqual(pr.week_ending(date(2026, 10, 12)).weekday(), 4)
        self.assertEqual(pr.week_ending(date(2026, 10, 16)), date(2026, 10, 16))


if __name__ == "__main__":
    unittest.main()
